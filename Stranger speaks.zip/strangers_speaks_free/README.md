# Strangers Speaks — Free MVP

This version is free: **no paid calls, no subscriptions, no coins, no wallet, and no payouts**. Those can be added later after the free matching experience is tested.

## Included
- Male accounts are queued only for female accounts, and female accounts only for male accounts.
- India-wide matching means users connected to the same deployed service can be matched regardless of state.
- Browser video/audio via WebRTC.
- Start, Next, End, mute, camera toggle, text chat and a basic report event.
- Mobile-friendly interface.

## Run locally
1. Install Node.js 18+.
2. Extract the ZIP and open a terminal in the project folder.
3. Run `npm install`
4. Run `npm start`
5. Open `http://localhost:3000` in a browser.
6. Test with two different browsers/devices and choose opposite genders.

## Before public launch
This is a prototype, not a production-ready service. The gender selection is self-declared and does not verify identity. The 18+ checkbox is not age verification. Before launch, implement reliable age/identity checks, moderation and report review, blocking, rate limits, privacy policy, terms, data protection, secure deployment, and abuse prevention. Do not advertise that all matches are genuine or guaranteed.

Camera/microphone require HTTPS on a public domain. This starter uses a public STUN server only; some networks require a TURN relay, which may have a cost. Deploy the Node.js app on a host that supports WebSockets; static-only hosting will not work.

The report button currently logs a server event only; it does not yet create a moderation dashboard or store evidence. No call recording is included.
